#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;
};
void printlist(struct node* n)
{
	while(n!=NULL)
	{
		printf(" %d ", n->data);
		n = n->next;
	}
}
int main()
{
struct node* head;
struct node* second;
struct node* thired;
head= (struct node*)malloc(sizeof(struct node));
second=(struct node*)malloc(sizeof(struct node));
thired=(struct node*)malloc(sizeof(struct node));
head->data=1;
head->next=second;
second->data=2;
second->next=thired;
thired->data=3;
thired->next=NULL;
printlist(head);
return 0;
}